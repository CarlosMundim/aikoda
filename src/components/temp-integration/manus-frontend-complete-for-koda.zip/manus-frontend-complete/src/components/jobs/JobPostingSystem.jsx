import { Briefcase, Plus, Edit, Eye } from 'lucide-react'

const JobPostingSystem = ({ language }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">
          {language === 'ja' ? '求人投稿システム' : 'Job Posting System'}
        </h1>
        <p className="text-muted-foreground">
          {language === 'ja' ? '文化的要件付き求人管理' : 'Job management with cultural requirements'}
        </p>
      </div>

      <div className="sap-card p-6">
        <h3 className="text-lg font-semibold mb-4">
          {language === 'ja' ? 'スマート求人作成' : 'Smart Job Creation'}
        </h3>
        <p className="text-muted-foreground">
          {language === 'ja' 
            ? '文化的要件とAI推奨を統合した求人投稿システム'
            : 'Job posting system with integrated cultural requirements and AI recommendations'
          }
        </p>
      </div>
    </div>
  )
}

export default JobPostingSystem


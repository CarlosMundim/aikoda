import { useState, useEffect } from 'react'
import { 
  TrendingUp, 
  Users, 
  Briefcase, 
  Target, 
  Brain,
  BarChart3,
  PieChart,
  Activity
} from 'lucide-react'

const ExecutiveAnalyticsCockpit = ({ language }) => {
  const [kpis, setKpis] = useState({
    totalCandidates: 0,
    activeJobs: 0,
    successfulMatches: 0,
    averageFitScore: 0
  })

  // Animate KPIs on load
  useEffect(() => {
    const animateKPIs = () => {
      const targetValues = {
        totalCandidates: 1247,
        activeJobs: 23,
        successfulMatches: 89,
        averageFitScore: 87
      }

      const duration = 2000
      const steps = 60
      const stepDuration = duration / steps

      let currentStep = 0
      const interval = setInterval(() => {
        currentStep++
        const progress = currentStep / steps

        setKpis({
          totalCandidates: Math.floor(targetValues.totalCandidates * progress),
          activeJobs: Math.floor(targetValues.activeJobs * progress),
          successfulMatches: Math.floor(targetValues.successfulMatches * progress),
          averageFitScore: Math.floor(targetValues.averageFitScore * progress)
        })

        if (currentStep >= steps) {
          clearInterval(interval)
        }
      }, stepDuration)

      return () => clearInterval(interval)
    }

    const timer = setTimeout(animateKPIs, 500)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">
            {language === 'ja' ? 'エグゼクティブダッシュボード' : 'Executive Dashboard'}
          </h1>
          <p className="text-muted-foreground">
            {language === 'ja' ? 'リアルタイム分析とKPI' : 'Real-time analytics and KPIs'}
          </p>
        </div>
        <div className="real-time-indicator">
          <span className="text-sm font-medium">
            {language === 'ja' ? 'リアルタイム' : 'Live'}
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="executive-dashboard-grid">
        <div className="sap-kpi-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="sap-kpi-value">{kpis.totalCandidates.toLocaleString()}</div>
              <div className="sap-kpi-label">
                {language === 'ja' ? '登録候補者数' : 'Total Candidates'}
              </div>
              <div className="sap-kpi-change positive">
                <TrendingUp className="h-3 w-3" />
                <span>+12.5%</span>
              </div>
            </div>
            <Users className="h-8 w-8 text-primary" />
          </div>
        </div>

        <div className="sap-kpi-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="sap-kpi-value">{kpis.activeJobs}</div>
              <div className="sap-kpi-label">
                {language === 'ja' ? 'アクティブ求人' : 'Active Jobs'}
              </div>
              <div className="sap-kpi-change positive">
                <TrendingUp className="h-3 w-3" />
                <span>+8.3%</span>
              </div>
            </div>
            <Briefcase className="h-8 w-8 text-primary" />
          </div>
        </div>

        <div className="sap-kpi-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="sap-kpi-value">{kpis.successfulMatches}</div>
              <div className="sap-kpi-label">
                {language === 'ja' ? '成功マッチング' : 'Successful Matches'}
              </div>
              <div className="sap-kpi-change positive">
                <TrendingUp className="h-3 w-3" />
                <span>+15.7%</span>
              </div>
            </div>
            <Target className="h-8 w-8 text-primary" />
          </div>
        </div>

        <div className="sap-kpi-card">
          <div className="flex items-center justify-between">
            <div>
              <div className="sap-kpi-value">{kpis.averageFitScore}%</div>
              <div className="sap-kpi-label">
                {language === 'ja' ? '平均適合スコア' : 'Average Fit Score'}
              </div>
              <div className="sap-kpi-change positive">
                <TrendingUp className="h-3 w-3" />
                <span>+3.2%</span>
              </div>
            </div>
            <Brain className="h-8 w-8 text-primary" />
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="analytics-chart-container">
          <div className="sap-chart-header">
            <h3 className="sap-chart-title">
              {language === 'ja' ? '文化的適合性トレンド' : 'Cultural Fit Trends'}
            </h3>
            <p className="sap-chart-description">
              {language === 'ja' ? '過去30日間' : 'Last 30 days'}
            </p>
          </div>
          <div className="h-64 flex items-center justify-center bg-muted/30 rounded-lg">
            <BarChart3 className="h-16 w-16 text-muted-foreground" />
          </div>
        </div>

        <div className="analytics-chart-container">
          <div className="sap-chart-header">
            <h3 className="sap-chart-title">
              {language === 'ja' ? '業界別分布' : 'Industry Distribution'}
            </h3>
            <p className="sap-chart-description">
              {language === 'ja' ? '候補者の業界分布' : 'Candidate industry breakdown'}
            </p>
          </div>
          <div className="h-64 flex items-center justify-center bg-muted/30 rounded-lg">
            <PieChart className="h-16 w-16 text-muted-foreground" />
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="sap-card">
        <div className="sap-card-header">
          <h3 className="text-lg font-semibold">
            {language === 'ja' ? '最近のアクティビティ' : 'Recent Activity'}
          </h3>
        </div>
        <div className="sap-card-content">
          <div className="space-y-4">
            {[
              {
                action: language === 'ja' ? '新規候補者登録' : 'New candidate registered',
                details: language === 'ja' ? '田中太郎さんがソフトウェアエンジニアとして登録' : 'Taro Tanaka registered as Software Engineer',
                time: '2分前'
              },
              {
                action: language === 'ja' ? 'AIマッチング完了' : 'AI matching completed',
                details: language === 'ja' ? '5名の候補者が新しい求人にマッチング' : '5 candidates matched to new job posting',
                time: '15分前'
              },
              {
                action: language === 'ja' ? '文化的適合性分析' : 'Cultural fit analysis',
                details: language === 'ja' ? '山田花子さんの文化的知能スコア: 92%' : 'Hanako Yamada cultural intelligence score: 92%',
                time: '1時間前'
              }
            ].map((activity, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                <Activity className="h-5 w-5 text-primary mt-0.5" />
                <div className="flex-1">
                  <p className="font-medium">{activity.action}</p>
                  <p className="text-sm text-muted-foreground">{activity.details}</p>
                  <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default ExecutiveAnalyticsCockpit

